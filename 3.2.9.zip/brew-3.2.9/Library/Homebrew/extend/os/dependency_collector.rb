# typed: strict
# frozen_string_literal: true

require "extend/os/mac/dependency_collector" if OS.mac?
