# typed: strict
# frozen_string_literal: true

require "extend/os/linux/api/analytics" if OS.linux?
