# typed: strict
# frozen_string_literal: true

require "extend/os/mac/formula_support" if OS.mac?
